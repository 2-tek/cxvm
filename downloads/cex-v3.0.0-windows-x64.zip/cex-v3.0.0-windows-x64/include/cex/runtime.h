// Cex Runtime Headers v3.0.0 for windows-x64
#ifndef CEX_RUNTIME_H
#define CEX_RUNTIME_H
#include <iostream>
#include <string>
#include <vector>
#define CEX_VERSION "3.0.0"
#define CEX_TARGET_TRIPLE "x86_64-pc-windows-msvc"
#endif

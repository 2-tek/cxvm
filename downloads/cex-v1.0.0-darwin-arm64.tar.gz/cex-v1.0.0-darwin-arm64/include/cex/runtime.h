// Cex Runtime Headers v1.0.0 for darwin-arm64
#ifndef CEX_RUNTIME_H
#define CEX_RUNTIME_H
#include <iostream>
#include <string>
#include <vector>
#define CEX_VERSION "1.0.0"
#define CEX_TARGET_TRIPLE "aarch64-apple-darwin"
#endif

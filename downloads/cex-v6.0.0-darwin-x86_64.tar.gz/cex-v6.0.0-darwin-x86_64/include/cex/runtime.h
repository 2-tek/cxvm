// Cex Runtime Headers v6.0.0 for darwin-x86_64
#ifndef CEX_RUNTIME_H
#define CEX_RUNTIME_H
#include <iostream>
#include <string>
#include <vector>
#define CEX_VERSION "6.0.0"
#define CEX_TARGET_TRIPLE "x86_64-apple-darwin"
#endif

// Cex Runtime Headers v1.1.0 for linux-aarch64
#ifndef CEX_RUNTIME_H
#define CEX_RUNTIME_H
#include <iostream>
#include <string>
#include <vector>
#define CEX_VERSION "1.1.0"
#define CEX_TARGET_TRIPLE "aarch64-unknown-linux-gnu"
#endif

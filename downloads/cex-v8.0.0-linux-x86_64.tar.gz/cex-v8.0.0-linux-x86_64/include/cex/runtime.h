// Cex Pure Native Runtime Definitions v8.0.0 for linux-x86_64 (CexR + CexP)
#ifndef CEX_RUNTIME_H
#define CEX_RUNTIME_H
#define CEX_VERSION "8.0.0"
#define CEX_TARGET_TRIPLE "x86_64-unknown-linux-gnu"
#define CEX_TOOLCHAIN_STANDARD "cexr+cexp"
#endif

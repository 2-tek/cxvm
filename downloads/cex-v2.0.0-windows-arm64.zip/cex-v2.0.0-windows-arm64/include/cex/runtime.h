// Cex Runtime Headers v2.0.0 for windows-arm64
#ifndef CEX_RUNTIME_H
#define CEX_RUNTIME_H
#include <iostream>
#include <string>
#include <vector>
#define CEX_VERSION "2.0.0"
#define CEX_TARGET_TRIPLE "aarch64-pc-windows-msvc"
#endif

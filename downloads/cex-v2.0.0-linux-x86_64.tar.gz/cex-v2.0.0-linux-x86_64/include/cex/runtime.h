// Cex Runtime Headers v2.0.0 for linux-x86_64
#ifndef CEX_RUNTIME_H
#define CEX_RUNTIME_H
#include <iostream>
#include <string>
#include <vector>
#define CEX_VERSION "2.0.0"
#define CEX_TARGET_TRIPLE "x86_64-unknown-linux-gnu"
#endif

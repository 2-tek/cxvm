// Cex Pure Native Runtime Definitions v3.0.0 for darwin-arm64 (CexR + CexP)
#ifndef CEX_RUNTIME_H
#define CEX_RUNTIME_H
#define CEX_VERSION "3.0.0"
#define CEX_TARGET_TRIPLE "aarch64-apple-darwin"
#define CEX_TOOLCHAIN_STANDARD "cexr+cexp"
#endif

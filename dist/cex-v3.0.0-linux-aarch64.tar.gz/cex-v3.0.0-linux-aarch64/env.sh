export CEX_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PATH="$CEX_HOME/bin:$PATH"

$env:CEX_HOME = $PSScriptRoot
$env:PATH = "$env:CEX_HOME\bin;$env:PATH"

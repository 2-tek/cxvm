// Cex Pure Native Runtime Definitions v1.0.0 for windows-x64 (CexR + CexP)
#ifndef CEX_RUNTIME_H
#define CEX_RUNTIME_H
#define CEX_VERSION "1.0.0"
#define CEX_TARGET_TRIPLE "x86_64-pc-windows-msvc"
#define CEX_TOOLCHAIN_STANDARD "cexr+cexp"
#endif

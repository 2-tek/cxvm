// Cex Pure Native Runtime Definitions v1.0.0 for linux-aarch64 (CexR + CexP)
#ifndef CEX_RUNTIME_H
#define CEX_RUNTIME_H
#define CEX_VERSION "1.0.0"
#define CEX_TARGET_TRIPLE "aarch64-unknown-linux-gnu"
#define CEX_TOOLCHAIN_STANDARD "cexr+cexp"
#endif

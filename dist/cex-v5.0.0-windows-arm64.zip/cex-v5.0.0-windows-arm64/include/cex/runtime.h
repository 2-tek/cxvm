// Cex Pure Native Runtime Definitions v5.0.0 for windows-arm64 (CexR + CexP)
#ifndef CEX_RUNTIME_H
#define CEX_RUNTIME_H
#define CEX_VERSION "5.0.0"
#define CEX_TARGET_TRIPLE "aarch64-pc-windows-msvc"
#define CEX_TOOLCHAIN_STANDARD "cexr+cexp"
#endif

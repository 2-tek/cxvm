@echo off
rem 2-TEK Cex Native Launcher for windows-arm64
cexr "%~dp0src/index.cex" %*

@echo off
rem 2-TEK Cex Native Launcher for windows-x64
cexr "%~dp0src/index.cex" %*
